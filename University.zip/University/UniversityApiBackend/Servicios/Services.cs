﻿using UniversityApiBackend.DataAccess;
using UniversityApiBackend.Models.DataModels;

namespace UniversityApiBackend.Servicios
{
    public class Services
    {
        private readonly UniversityDbConext context;
        public Services(UniversityDbConext _context)
        {
            context = _context;
        }
        public User GetUser(string email) 
        {
            return context.Users.FirstOrDefault(u => u.Email == email);
        }
        public ICollection<Student> GetStudents() 
        {
            return context.Students.Where(s => s.User.Age > 17).ToList();
        }
        public ICollection<Student> GetStudentsCursos()
        {
            return context.Students.Where(s => s.Courses.Any()).ToList();
        }
        public ICollection<Course> GetCourses(Lavel _level)
        {
            return context.Courses.Where(c => c.Lavel == _level && c.Students.Any()).ToList();
        }
        public ICollection<Course> GetCoursesCategory(Lavel _level)
        {
            return context.Courses.Where(c => c.Lavel == _level && c.Categories.Any()).ToList();
        }
        public ICollection<Course> GetCoursesSinAlumnos()
        {
            return context.Courses.Where(c => !c.Students.Any()).ToList();
        }
    }
}
