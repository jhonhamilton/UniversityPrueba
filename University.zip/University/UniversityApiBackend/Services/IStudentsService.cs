﻿using UniversityApiBackend.Models.DataModels;

namespace UniversityApiBackend.Services
{
    public interface IStudentsService
    {
        IEnumerable<Student> GetStudentsWithCourses();
        IEnumerable<Student> GetStudentsWithNoCourses();
        IEnumerable<Student> GetStudentsByCourse(Course course);

        IEnumerable<Course> GetCoursesOfCategory(Lavel _level);
        IEnumerable<Course> GetCoursesNoTemaries();
        IEnumerable<Course> GetCoursesByStudent(Student student);
    }
}
