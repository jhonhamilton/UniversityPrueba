﻿using Microsoft.EntityFrameworkCore;
using UniversityApiBackend.DataAccess;
using UniversityApiBackend.Models.DataModels;

namespace UniversityApiBackend.Services
{
    public class StudentsService : IStudentsService
    {
        private readonly UniversityDbConext context;
        public StudentsService(UniversityDbConext _context)
        {
            context = _context;
        }
        public User GetUser(string email) 
        {
            return context.Users.FirstOrDefault(u => u.Email == email);
        }
        public ICollection<Student> GetStudents() 
        {
            return context.Students.Where(s => s.User.Age > 17).ToList();
        }
        public ICollection<Student> GetStudentsCursos()
        {
            return context.Students.Where(s => s.Courses.Any()).ToList();
        }
        public ICollection<Course> GetCourses(Lavel _level)
        {
            return context.Courses.Where(c => c.Lavel == _level && c.Students.Any()).ToList();
        }
        public ICollection<Course> GetCoursesCategory(Lavel _level)
        {
            return context.Courses.Where(c => c.Lavel == _level && c.Categories.Any()).ToList();
        }
        public ICollection<Course> GetCoursesSinAlumnos()
        {
            return context.Courses.Where(c => !c.Students.Any()).ToList();
        }

        public IEnumerable<Student> GetStudentsWithCourses()
        {
            return context.Students.Where(s => s.Courses.Any()).ToList();
        }
        //public async Task<IEnumerable<Student>> GetStudentsWithCourses()
        //{
        //    return await context.Students.Where(s => s.Courses.Any()).ToListAsync();
        //}

        public IEnumerable<Student> GetStudentsWithNoCourses()
        {
            return context.Students.Where(s => !s.Courses.Any()).ToList();
        }
        public IEnumerable<Course> GetCoursesOfCategory(Lavel _level)
        {
            return context.Courses.Where(c => c.Lavel == _level && c.Categories.Any()).ToList();
        }
        public IEnumerable<Course> GetCoursesNoTemaries()
        {
            return context.Courses.Where(c => c.Chapter.List == "").ToList();
        }
        public IEnumerable<Student> GetStudentsByCourse(Course course)
        {
            return context.Students.Where(s => s.Courses.Any(c => c.Name == course.Name)).ToList();
        }
        public IEnumerable<Course> GetCoursesByStudent(Student student)
        {
            return context.Courses.Where(c => c.Students.Any(s => s.Name == student.Name)).ToList();
        }
    }
}
